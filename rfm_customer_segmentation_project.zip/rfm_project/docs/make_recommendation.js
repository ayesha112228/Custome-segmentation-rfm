const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, ShadingType,
        BorderStyle, AlignmentType, LevelFormat } = require('docx');

const NAVY = "14213D", GREY = "5C677D";
const font = "Calibri";
const run = (t, o = {}) => new TextRun({ text: t, font, size: 19, ...o });
const p = (children, o = {}) => new Paragraph({ spacing: { after: 70 }, children: Array.isArray(children) ? children : [run(children)], ...o });
const h = (t) => new Paragraph({ spacing: { before: 130, after: 50 }, keepNext: true,
  border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "C9D1DB", space: 1 } },
  children: [new TextRun({ text: t, font, size: 22, bold: true, color: NAVY })] });
const bullet = (parts) => new Paragraph({ numbering: { reference: "b", level: 0 }, spacing: { after: 50 },
  children: parts.map(x => typeof x === 'string' ? run(x) : run(x.t, { bold: true })) });

// ---- segment table
const widths = [1900, 1050, 1050, 1250, 1050, 2726];   // sums to 9026 (A4 content width)
const border = { style: BorderStyle.SINGLE, size: 4, color: "D5DBE3" };
const borders = { top: border, bottom: border, left: border, right: border };
const cell = (t, w, o = {}) => new TableCell({
  width: { size: w, type: WidthType.DXA }, borders,
  margins: { top: 40, bottom: 40, left: 80, right: 80 },
  shading: o.fill ? { fill: o.fill, type: ShadingType.CLEAR, color: "auto" } : undefined,
  children: [new Paragraph({ alignment: o.align || AlignmentType.LEFT,
    children: [new TextRun({ text: t, font, size: 17, bold: !!o.bold, color: o.color || "1B1B1B" })] })] });

const rows = [
  ["Segment", "Customers", "% revenue", "Revenue", "Avg recency", "Role in the plan"],
  ["Champions", "423", "47%", "£3.03M", "62 days", "Protect, reward, don't discount"],
  ["Loyal", "472", "21%", "£1.34M", "137 days", "Grow basket via bundles"],
  ["Can't Lose Them", "264", "24%", "£1.57M", "345 days", "Win back first: biggest prize"],
  ["At Risk", "161", "3%", "£0.21M", "408 days", "Targeted win-back"],
  ["New Customers", "357", "1%", "£0.08M", "39 days", "Secure the second order"],
  ["Promising", "308", "2%", "£0.11M", "165 days", "Nurture with replenishment"],
  ["Hibernating", "615", "2%", "£0.16M", "492 days", "Low-cost email, then suppress"],
];
const tbl = new Table({
  width: { size: 9026, type: WidthType.DXA }, columnWidths: widths,
  rows: rows.map((r, i) => new TableRow({ tableHeader: i === 0, children: r.map((t, j) =>
    cell(t, widths[j], i === 0 ? { fill: NAVY, bold: true, color: "FFFFFF", align: j > 0 && j < 5 ? AlignmentType.CENTER : AlignmentType.LEFT }
      : { fill: (r[0] === "Can't Lose Them") ? "FBE3E6" : undefined, bold: j === 0, align: j > 0 && j < 5 ? AlignmentType.CENTER : AlignmentType.LEFT })) })),
});

const doc = new Document({
  numbering: { config: [{ reference: "b", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 360, hanging: 240 } } } }] }] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 850, bottom: 700, left: 1440, right: 1440 } } },
    children: [
      new Paragraph({ spacing: { after: 20 }, children: [new TextRun({ text: "Customer Segmentation: CRM Recommendation", font, size: 34, bold: true, color: NAVY })] }),
      new Paragraph({ spacing: { after: 100 }, children: [new TextRun({ text: "RFM analysis of 2,600 customers, £6.5M revenue, snapshot 9 Dec 2011 (synthetic Online Retail II-style data)", font, size: 17, color: GREY })] }),

      h("The headline"),
      p([run("Revenue is highly concentrated, and a large part of it is quietly leaving. "),
         run("Champions are 16% of customers but 47% of revenue. ", { bold: true }),
         run("The bigger concern is the Can't Lose Them group: 264 high-spend, high-frequency customers (£1.57M, 24% of revenue) who have not ordered for about 345 days on average. Only 63% of customers have ordered twice, and 357 new customers have yet to place a second order.")]),

      h("Segment snapshot"),
      tbl,

      h("Where to focus (in priority order)"),
      bullet([{ t: "1. Win back Can't Lose Them (264). " }, "Personal outreach, not a mass blast: account-manager call or tailored email naming their usual categories, with a time-limited offer. This is the highest value per contact in the base (average order £523)."]),
      bullet([{ t: "2. Secure order #2 for New Customers (357). " }, "Welcome series, then a second-purchase incentive inside 30 days. The repeat rate of earlier cohorts shows what a retained customer is worth: 66-83% of 2010 cohorts went on to reorder."]),
      bullet([{ t: "3. Win back At Risk (161) with a lighter touch. " }, "Automated 3-email sequence with category recommendations; escalate only those with high past spend."]),
      bullet([{ t: "4. Protect Champions (423) and grow Loyal (472). " }, "Early access, referral rewards and bundles. Avoid blanket discounts: these customers already buy. Cross-sell to lift basket size."]),
      bullet([{ t: "5. Cut spend on Hibernating (615). " }, "One low-cost reactivation email; suppress non-responders. They are 24% of customers but 2% of revenue."]),

      h("Sizing the opportunity (illustrative assumptions)"),
      p([run("Reactivating 15% of Can't Lose Them for 4 orders (≈£83k), 10% of At Risk for 3 orders (≈£14k) and lifting second-order conversion of New Customers by 15 points for 2 further orders (≈£25k) is worth "),
         run("about £121k, roughly 4% of trailing-12-month revenue (£3.09M).", { bold: true }),
         run(" The dashboard includes an adjustable what-if calculator so the assumptions can be changed.")]),

      h("How we would measure it"),
      p("Hold out a random 10% of each targeted segment as a control. Track reactivation rate, second-order rate within 30 days, revenue per customer and campaign margin by segment. Review segment migration monthly: customers moving from Loyal to At Risk are the early-warning signal."),

      h("Caveats"),
      p([run("Segments use lifetime revenue before returns (returns ≈ 1.9% of revenue). Recent cohorts are still maturing, so repeat rates for late 2011 are understated. The December 2011 month is partial. Figures come from synthetic data built to mirror the Online Retail II schema; rerunning the pipeline on the real dataset will change the numbers but not the method.", { color: GREY, size: 17 })]),
    ],
  }],
});
Packer.toBuffer(doc).then(b => fs.writeFileSync("Recommendation_One_Pager.docx", b));
