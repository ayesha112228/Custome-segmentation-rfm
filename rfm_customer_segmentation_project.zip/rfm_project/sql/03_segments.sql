-- =====================================================================
-- 03_segments.sql  |  Rule-based RFM segments + segment dimension
-- Input : rfm_scores     Output: customer_segments, dim_segment
-- =====================================================================
DROP TABLE IF EXISTS customer_segments;
CREATE TABLE customer_segments AS
SELECT s.*,
       CAST(r_score AS TEXT) || CAST(f_score AS TEXT) || CAST(m_score AS TEXT) AS rfm_code,
       r_score + f_score + m_score                                              AS rfm_total,
       -- order matters: first matching rule wins
       CASE
         WHEN r_score >= 4 AND f_score >= 4 AND m_score >= 4 THEN 'Champions'
         WHEN r_score <= 2 AND f_score >= 4 AND m_score >= 4 THEN 'Cant Lose Them'
         WHEN r_score >= 3 AND f_score >= 3 THEN 'Loyal'
         WHEN r_score <= 2 AND f_score >= 3 THEN 'At Risk'
         WHEN r_score >= 4 AND f_score  = 1 THEN 'New Customers'
         WHEN r_score >= 3 AND f_score <= 2 THEN 'Promising'
         ELSE 'Hibernating'
       END AS segment
FROM rfm_scores s;

DROP TABLE IF EXISTS dim_segment;
CREATE TABLE dim_segment (
    segment        TEXT PRIMARY KEY,
    sort_order     INTEGER,
    definition     TEXT,
    priority       TEXT,
    recommended_action TEXT
);
INSERT INTO dim_segment VALUES
('Champions',      1, 'Bought recently, buy often, spend a lot (R>=4, F>=4, M>=4)',        'Protect',  'Early access, referral rewards, no discounts needed'),
('Loyal',          2, 'Regular buyers, fairly recent (R>=3, F>=3)',     'Grow',     'Cross-sell / bundle offers, loyalty tier upgrade'),
('New Customers',  3, 'First purchase very recently (R>=4, F=1)',       'Convert',  'Welcome series, second-purchase incentive within 30 days'),
('Promising',      4, 'Recent but only 1-2 orders (R>=3, F<=2)',        'Convert',  'Replenishment reminders, category recommendations'),
('At Risk',        5, 'Used to buy regularly, gone quiet (R<=2, F>=3)','Win back', 'Personalised win-back with time-limited offer'),
('Cant Lose Them', 6, 'High-frequency, high-spend customers now lapsed (R<=2, F>=4, M>=4)','Win back', 'Direct outreach, account-manager call, best offer'),
('Hibernating',    7, 'Low frequency and not seen for a long time',     'Light touch','Low-cost reactivation email, then suppress to save spend');
