-- =====================================================================
-- 02_rfm_scores.sql  |  Recency, Frequency, Monetary + 1-5 scores
-- Input : clean_orders
-- Output: rfm_base, rfm_scores
-- =====================================================================

-- Snapshot date = day after the last order in the data (never use "today")
DROP TABLE IF EXISTS params;
CREATE TABLE params AS
SELECT date(MAX(order_date), '+1 day') AS snapshot_date FROM clean_orders;

DROP TABLE IF EXISTS rfm_base;
CREATE TABLE rfm_base AS
SELECT o.customer_id,
       MAX(o.country)                                              AS country,
       MIN(o.order_date)                                           AS first_order_date,
       MAX(o.order_date)                                           AS last_order_date,
       CAST(julianday(p.snapshot_date) - julianday(MAX(o.order_date)) AS INTEGER) AS recency_days,
       COUNT(DISTINCT o.invoice)                                   AS frequency,
       ROUND(SUM(o.order_value), 2)                                AS monetary,
       ROUND(SUM(o.order_value) * 1.0 / COUNT(DISTINCT o.invoice), 2) AS avg_order_value
FROM clean_orders o CROSS JOIN params p
GROUP BY o.customer_id;

-- Scoring
--  R: quintile, MOST RECENT = 5  (NTILE ordered by recency DESC)
--  M: quintile, HIGHEST SPEND = 5
--  F: fixed business bands, not NTILE. ~40% of customers bought exactly once,
--     so quintiles would split identical customers into different scores.
DROP TABLE IF EXISTS rfm_scores;
CREATE TABLE rfm_scores AS
SELECT b.*,
       NTILE(5) OVER (ORDER BY recency_days DESC, customer_id) AS r_score,
       CASE WHEN frequency = 1  THEN 1
            WHEN frequency = 2  THEN 2
            WHEN frequency <= 6 THEN 3
            WHEN frequency <= 12 THEN 4
            ELSE 5 END                                          AS f_score,
       NTILE(5) OVER (ORDER BY monetary ASC, customer_id)       AS m_score
FROM rfm_base b;
