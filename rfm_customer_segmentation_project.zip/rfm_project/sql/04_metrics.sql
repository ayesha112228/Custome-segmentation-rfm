-- =====================================================================
-- 04_metrics.sql  |  Tables that feed the Power BI dashboard
-- Output: fact_orders, segment_summary, cohort_retention,
--         monthly_revenue_segment, repeat_purchase, revenue_concentration
-- =====================================================================

-- ---- Order-level fact table (join key: customer_id) -------------------
DROP TABLE IF EXISTS fact_orders;
CREATE TABLE fact_orders AS
SELECT o.invoice, o.customer_id, o.order_date,
       strftime('%Y-%m', o.order_date) AS order_month,
       o.country, o.line_count, o.units, o.order_value,
       -- 1 if this is the customer's first invoice
       CASE WHEN o.order_date = c.first_order_date
             AND o.invoice = (SELECT MIN(x.invoice) FROM clean_orders x
                              WHERE x.customer_id = o.customer_id AND x.order_date = c.first_order_date)
            THEN 1 ELSE 0 END AS is_first_order
FROM clean_orders o
JOIN customer_segments c USING (customer_id);

-- ---- Segment summary -------------------------------------------------
DROP TABLE IF EXISTS segment_summary;
CREATE TABLE segment_summary AS
SELECT c.segment,
       d.sort_order,
       COUNT(*)                                                    AS customers,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1)          AS pct_customers,
       ROUND(SUM(c.monetary), 0)                                   AS revenue,
       ROUND(100.0 * SUM(c.monetary) / SUM(SUM(c.monetary)) OVER (), 1) AS pct_revenue,
       ROUND(AVG(c.monetary), 0)                                   AS avg_revenue_per_customer,
       ROUND(AVG(c.frequency), 1)                                  AS avg_orders,
       ROUND(SUM(c.monetary) / SUM(c.frequency), 0)                AS avg_order_value,
       ROUND(AVG(c.recency_days), 0)                               AS avg_recency_days,
       ROUND(100.0 * SUM(CASE WHEN c.frequency >= 2 THEN 1 ELSE 0 END) / COUNT(*), 1) AS repeat_rate_pct
FROM customer_segments c
JOIN dim_segment d USING (segment)
GROUP BY c.segment, d.sort_order
ORDER BY d.sort_order;

-- ---- Cohort retention (first-purchase month x months since) ----------
DROP TABLE IF EXISTS cohort_retention;
CREATE TABLE cohort_retention AS
WITH cust AS (
    SELECT customer_id, strftime('%Y-%m', first_order_date) AS cohort_month,
           CAST(strftime('%Y', first_order_date) AS INTEGER) * 12 +
           CAST(strftime('%m', first_order_date) AS INTEGER)  AS cohort_idx
    FROM customer_segments
),
activity AS (
    SELECT DISTINCT o.customer_id,
           CAST(strftime('%Y', o.order_date) AS INTEGER) * 12 +
           CAST(strftime('%m', o.order_date) AS INTEGER)  AS order_idx
    FROM clean_orders o
),
joined AS (
    SELECT c.cohort_month, a.order_idx - c.cohort_idx AS months_since, a.customer_id
    FROM cust c JOIN activity a USING (customer_id)
),
agg AS (
    SELECT cohort_month, months_since, COUNT(DISTINCT customer_id) AS active_customers
    FROM joined GROUP BY cohort_month, months_since
)
SELECT a.cohort_month, a.months_since, a.active_customers,
       s.active_customers AS cohort_size,
       ROUND(100.0 * a.active_customers / s.active_customers, 1) AS retention_pct
FROM agg a
JOIN agg s ON s.cohort_month = a.cohort_month AND s.months_since = 0
ORDER BY a.cohort_month, a.months_since;

-- ---- Monthly revenue by (current) segment -----------------------------
DROP TABLE IF EXISTS monthly_revenue_segment;
CREATE TABLE monthly_revenue_segment AS
SELECT f.order_month, c.segment,
       COUNT(DISTINCT f.customer_id) AS active_customers,
       COUNT(*)                      AS orders,
       ROUND(SUM(f.order_value), 0)  AS revenue
FROM fact_orders f JOIN customer_segments c USING (customer_id)
GROUP BY f.order_month, c.segment
ORDER BY f.order_month, c.segment;

-- ---- Repeat purchase rate by first-order quarter ----------------------
DROP TABLE IF EXISTS repeat_purchase;
CREATE TABLE repeat_purchase AS
SELECT strftime('%Y', first_order_date) || '-Q' ||
       ((CAST(strftime('%m', first_order_date) AS INTEGER) + 2) / 3) AS first_order_quarter,
       COUNT(*)                                                   AS customers,
       SUM(CASE WHEN frequency >= 2 THEN 1 ELSE 0 END)            AS repeat_customers,
       ROUND(100.0 * SUM(CASE WHEN frequency >= 2 THEN 1 ELSE 0 END) / COUNT(*), 1) AS repeat_rate_pct
FROM customer_segments
GROUP BY 1
ORDER BY 1;

-- ---- Revenue concentration (Pareto) ------------------------------------
DROP TABLE IF EXISTS revenue_concentration;
CREATE TABLE revenue_concentration AS
WITH ranked AS (
    SELECT customer_id, monetary,
           NTILE(10) OVER (ORDER BY monetary DESC, customer_id) AS decile
    FROM customer_segments
)
SELECT decile,
       COUNT(*)                                                   AS customers,
       ROUND(SUM(monetary), 0)                                    AS revenue,
       ROUND(100.0 * SUM(monetary) / SUM(SUM(monetary)) OVER (), 1) AS pct_revenue
FROM ranked GROUP BY decile ORDER BY decile;
