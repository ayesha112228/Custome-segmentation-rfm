-- =====================================================================
-- 01_clean.sql  |  Clean raw retail lines -> clean_lines, clean_orders
-- Dialect: SQLite (ANSI-style; T-SQL / Postgres notes at bottom of file)
-- Input  : raw_retail(invoice, stock_code, description, quantity,
--                     invoice_date, price, customer_id, country)
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Data-quality log: why rows are excluded (first matching reason wins)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS dq_log;
CREATE TABLE dq_log AS
SELECT reason, COUNT(*) AS row_count,
       ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM raw_retail), 2) AS pct_of_raw
FROM (
    SELECT CASE
             WHEN customer_id IS NULL                                   THEN '1. Missing customer ID (guest checkout)'
             WHEN invoice LIKE 'C%'                                      THEN '2. Cancellation / return invoice'
             WHEN quantity <= 0                                          THEN '3. Non-positive quantity'
             WHEN price <= 0                                             THEN '4. Zero / negative price'
             WHEN stock_code IN ('POST','D','M','BANK CHARGES','DOT',
                                 'CRUK','AMAZONFEE','ADJUST','TEST001')  THEN '5. Non-product stock code (postage, fees, discounts)'
             ELSE '0. Kept'
           END AS reason
    FROM raw_retail
)
GROUP BY reason
ORDER BY reason;

-- ---------------------------------------------------------------------
-- 2. Clean line items. DISTINCT drops exact duplicate lines.
--    (On real data, review this: identical repeated lines can be legitimate.)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS clean_lines;
CREATE TABLE clean_lines AS
SELECT DISTINCT
       invoice,
       stock_code,
       description,
       quantity,
       invoice_date,
       substr(invoice_date, 1, 10)      AS order_date,
       price,
       CAST(customer_id AS INTEGER)     AS customer_id,
       country,
       ROUND(quantity * price, 2)       AS line_total
FROM raw_retail
WHERE customer_id IS NOT NULL
  AND invoice NOT LIKE 'C%'
  AND quantity > 0
  AND price > 0
  AND stock_code NOT IN ('POST','D','M','BANK CHARGES','DOT','CRUK','AMAZONFEE','ADJUST','TEST001');

-- ---------------------------------------------------------------------
-- 3. One row per invoice (the grain for frequency and AOV)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS clean_orders;
CREATE TABLE clean_orders AS
SELECT invoice,
       customer_id,
       MIN(order_date)           AS order_date,
       MAX(country)              AS country,
       COUNT(*)                  AS line_count,
       SUM(quantity)             AS units,
       ROUND(SUM(line_total), 2) AS order_value
FROM clean_lines
GROUP BY invoice, customer_id;

-- ---------------------------------------------------------------------
-- 4. Returns by customer (kept separate so net revenue can be reported)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS customer_returns;
CREATE TABLE customer_returns AS
SELECT CAST(customer_id AS INTEGER)               AS customer_id,
       COUNT(DISTINCT invoice)                    AS return_invoices,
       ROUND(SUM(ABS(quantity) * price), 2)       AS return_value
FROM raw_retail
WHERE customer_id IS NOT NULL AND invoice LIKE 'C%'
GROUP BY customer_id;

-- Porting notes
--  * SQL Server: replace substr -> SUBSTRING, DISTINCT is fine, use CAST(... AS DATE).
--  * Postgres : substr works; use ::date casts.
