# Power BI build guide (about 60-90 minutes)

I can't produce a `.pbix` from here, so this guide gets you there quickly. Everything the
dashboard needs is already in `data/processed/`, and `powerbi/dashboard_preview.png` shows the target.

## 1. Load the data
Home > Get data > Text/CSV. Load these from `data/processed/`:

| File | Role |
|---|---|
| `dim_customer.csv` | Dimension: one row per customer with RFM scores and segment |
| `fact_orders.csv` | Fact: one row per invoice |
| `dim_segment.csv` | Dimension: segment order, definition, recommended action |
| `dim_date.csv` | Date table |
| `cohort_retention.csv` | Pre-aggregated cohort table (standalone) |
| `repeat_purchase.csv` | Repeat rate by first-order quarter (standalone) |

In Power Query set types: all `*date*` columns = Date; `customer_id` = Whole number (Text if you prefer, but be consistent);
money columns = Fixed decimal number. Close & Apply.

## 2. Data model (Model view)
```
dim_segment (1) ──< dim_customer (1) ──< fact_orders >── (1) dim_date
      segment            customer_id          order_date        date
```
- `dim_segment[segment]` → `dim_customer[segment]` (one-to-many, single direction)
- `dim_customer[customer_id]` → `fact_orders[customer_id]` (one-to-many, single direction)
- `dim_date[date]` → `fact_orders[order_date]` (one-to-many)
- Right-click `dim_date` > Mark as date table (column `date`)
- Sort `dim_segment[segment]` by `sort_order`; sort `dim_date[month_name]` by `month_num`
- Leave `cohort_retention` and `repeat_purchase` unrelated

## 3. Theme and measures
- View > Themes > Browse for themes > `powerbi/rfm_theme.json`
- Create an empty table named `_Measures` and paste measures from `powerbi/dax_measures.dax`
- Create the two What-if parameters (Modeling > New parameter): `Win-back Rate` (0 to 0.5, step 0.05, default 0.15) and `Orders per Reactivated Customer` (1 to 8, default 4). Power BI names the generated measures `Win-back Rate Value` and `Orders per Reactivated Customer Value`, which the `Winback Revenue Uplift` measure uses.

## 4. Pages

**Page 1: Executive overview** (the preview image)
- KPI cards: `Customers`, `Total Revenue`, `Repeat Purchase Rate`, `Avg Order Value`, `Revenue % of Total` (filtered to Champions), `Revenue at Risk`
- Bar: customers by `dim_segment[segment]`; bar: `Total Revenue` by segment (conditional colour with `Segment Color`)
- Stacked area: `fact_orders` revenue by `dim_date[year_month]`, legend = segment
- Slicers: country, date range

**Page 2: Segment deep dive**
- Matrix: segment rows with `Customers`, `Customers % of Total`, `Total Revenue`, `Revenue % of Total`, `Avg Recency (days)`, `Avg Frequency`, `Avg Order Value`, `Repeat Purchase Rate`
- Scatter: x = `Avg Recency (days)`, y = `Avg Frequency`, size = `Total Revenue`, details = segment
- Tooltip page showing the segment's `recommended_action`

**Page 3: Retention and cohorts**
- Matrix: rows = `cohort_month`, columns = `months_since`, values = `Cohort Retention %`; conditional format background as a colour scale. Filter `months_since` <= 12.
- Line: `New Customers (in period)` vs `Returning Customers (in period)` by month
- Column: `repeat_purchase[repeat_rate_pct]` by `first_order_quarter`; card: `Month 3 Retention %` (visual filter cohort_month <= 2011-08)

**Page 4: Action list and scenario**
- Table: `customer_id`, `country`, `segment`, `recency_days`, `frequency`, `monetary`, `rfm_code`; slicer on segment (this is the export list a CRM team would use)
- What-if sliders plus card `Winback Revenue Uplift`
- Text box with the three recommendations from `docs/Recommendation_One_Pager.docx`

## 5. Finish
- Name pages, hide the `_Measures` helper columns, align visuals to a grid
- File > Save as `Customer_Segmentation_Dashboard.pbix`; export page 1 as an image for the README / portfolio
- Publish to the Power BI Service if you have a work/school account (free personal accounts can't publish to web)

## Using the real Online Retail II data
Download from Kaggle, save as `data/raw/online_retail_II.csv`, run `python python/02_run_pipeline.py`, then
refresh the Power BI queries. The pipeline accepts both `Invoice`/`Price`/`Customer ID` and the older
`InvoiceNo`/`UnitPrice`/`CustomerID` column names. Real-data notes: segment sizes will differ, so check the
F-score bands in `sql/02_rfm_scores.sql` against your own frequency distribution; the real file also has
codes such as `S`, `B` and `gift_*` that you may want to add to the exclusion list in `sql/01_clean.sql`.
