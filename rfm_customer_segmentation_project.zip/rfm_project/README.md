# Customer Segmentation & CRM Campaign Performance (RFM)

End-to-end analytics project: SQL cleaning, RFM scoring and segmentation, retention metrics, a Power BI dashboard spec, and a one-page business recommendation.

> **Data note:** this environment had no internet access, so the data is **synthetic**, generated to match the
> Kaggle/UCI *Online Retail II* schema (including guest checkouts, returns, zero prices, fee rows and duplicates).
> The pipeline runs unchanged on the real file; see `powerbi/POWERBI_BUILD_GUIDE.md`.
> The `.pbix` itself must be built in Power BI Desktop; the guide, DAX, theme and preview image get you there fast.

## Structure
```
data/raw/online_retail_II.csv      raw transactions (~201k lines)
data/processed/*.csv               model-ready tables for Power BI
data/retail.db                     SQLite database with every intermediate table
sql/01_clean.sql                   cleaning rules + data-quality log
sql/02_rfm_scores.sql              recency / frequency / monetary and 1-5 scores
sql/03_segments.sql                7 rule-based segments + dim_segment
sql/04_metrics.sql                 fact table, segment summary, cohorts, repeat rate, Pareto
python/01_generate_synthetic_data.py
python/02_run_pipeline.py          load -> SQL -> export (run this on real data too)
python/03_dashboard_preview.py     renders powerbi/dashboard_preview.png
powerbi/                           DAX measures, theme, build guide, preview image
docs/Recommendation_One_Pager.docx / .pdf
```

## Run it
```
pip install pandas numpy matplotlib
python python/01_generate_synthetic_data.py     # skip if using the real dataset
python python/02_run_pipeline.py
python python/03_dashboard_preview.py
```

## Method
1. **Clean**: drop guest checkouts, returns (`C` invoices), non-positive quantity/price, non-product codes, exact duplicate lines. Every exclusion is counted in `dq_log`.
2. **RFM**: recency = days from last order to snapshot date (last order + 1 day); frequency = distinct invoices; monetary = sum of order value.
3. **Scores**: R and M are quintiles (`NTILE(5)`). F uses fixed bands (1, 2, 3-6, 7-12, 13+) because many customers bought once, so quintiles would split identical customers.
4. **Segments**: Champions, Loyal, Can't Lose Them, At Risk, New Customers, Promising, Hibernating; first matching rule wins (see `03_segments.sql`).
5. **Metrics**: segment summary, repeat purchase rate, cohort retention, monthly revenue by segment, revenue concentration (deciles).

## Headline results (synthetic data)
- 2,600 customers, £6.50M revenue, 62.7% repeat purchase rate, AOV £374
- Champions: 16% of customers, 47% of revenue
- Can't Lose Them: 264 customers, £1.57M (24% of revenue), ~345 days since last order
- Top 10% of customers generate 49% of revenue

## Known limitations (worth saying in an interview)
- Segments are a snapshot, so the monthly-revenue-by-segment chart assigns each customer's *current* segment to their past orders.
- Recent cohorts are right-censored; their repeat rate is understated.
- RFM is descriptive: the uplift figures in the recommendation are scenarios, not forecasts. A holdout test would measure them.

## SQL dialect
Written for SQLite. For SQL Server: `julianday` diff → `DATEDIFF(day, ...)`, `strftime('%Y-%m', d)` → `FORMAT(d,'yyyy-MM')`,
`date(x,'+1 day')` → `DATEADD(day,1,x)`, `CREATE TABLE ... AS SELECT` → `SELECT ... INTO`. `NTILE` and window functions are unchanged.
