"""Render a static preview of the target Power BI dashboard from the processed CSVs."""
from pathlib import Path
import pandas as pd, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / "data" / "processed"
seg = pd.read_csv(P / "segment_summary.csv").sort_values("sort_order")
coh = pd.read_csv(P / "cohort_retention.csv")
mrs = pd.read_csv(P / "monthly_revenue_segment.csv")
rep = pd.read_csv(P / "repeat_purchase.csv")
cust = pd.read_csv(P / "dim_customer.csv")

COL = {"Champions": "#0B6E4F", "Loyal": "#3FA96B", "New Customers": "#2D7DD2", "Promising": "#7FB7E6",
       "At Risk": "#F2A541", "Cant Lose Them": "#D1495B", "Hibernating": "#9AA5B1"}
NAVY = "#14213D"
plt.rcParams.update({"font.family": "DejaVu Sans", "axes.spines.top": False, "axes.spines.right": False})

fig = plt.figure(figsize=(16, 9.5), facecolor="#F5F7FA")
fig.text(0.03, 0.955, "Customer Segmentation & CRM Performance", fontsize=20, fontweight="bold", color=NAVY)
fig.text(0.03, 0.925, "RFM segments | snapshot 2011-12-09 | synthetic Online Retail II-style data", fontsize=10.5, color="#5C677D")

# ---- KPI cards
total_rev = cust.monetary.sum(); n = len(cust)
kpis = [("Customers", f"{n:,}"), ("Revenue", f"£{total_rev/1e6:.2f}M"),
        ("Repeat purchase rate", f"{(cust.frequency>=2).mean()*100:.1f}%"),
        ("Avg order value", f"£{total_rev/cust.frequency.sum():,.0f}"),
        ("Revenue from Champions", f"{seg.loc[seg.segment=='Champions','pct_revenue'].iloc[0]:.0f}%"),
        ("Revenue at risk*", f"£{(seg.loc[seg.segment.isin(['At Risk','Cant Lose Them']),'revenue'].sum())/1e6:.2f}M")]
for i, (lab, val) in enumerate(kpis):
    ax = fig.add_axes([0.03 + i * 0.158, 0.80, 0.148, 0.095]); ax.axis("off")
    ax.add_patch(plt.Rectangle((0, 0), 1, 1, transform=ax.transAxes, color="white", ec="#DDE3EA"))
    ax.text(0.06, 0.62, val, fontsize=19, fontweight="bold", color=NAVY, transform=ax.transAxes)
    ax.text(0.06, 0.18, lab, fontsize=9.5, color="#5C677D", transform=ax.transAxes)

# ---- segment size (customers) and revenue share
ax = fig.add_axes([0.115, 0.47, 0.22, 0.28]); ax.set_facecolor("white")
ax.barh(seg.segment[::-1], seg.customers[::-1], color=[COL[s] for s in seg.segment[::-1]])
for y, (v, p) in enumerate(zip(seg.customers[::-1], seg.pct_customers[::-1])):
    ax.text(v + 8, y, f"{v:,} ({p:.0f}%)", va="center", fontsize=8.5)
ax.set_title("Customers by segment", loc="left", fontsize=11, fontweight="bold", color=NAVY); ax.set_xlim(0, seg.customers.max() * 1.35)

ax = fig.add_axes([0.40, 0.47, 0.26, 0.28]); ax.set_facecolor("white")
ax.barh(seg.segment[::-1], seg.revenue[::-1] / 1e6, color=[COL[s] for s in seg.segment[::-1]])
for y, (v, p) in enumerate(zip(seg.revenue[::-1] / 1e6, seg.pct_revenue[::-1])):
    ax.text(v + 0.03, y, f"£{v:.2f}M ({p:.0f}%)", va="center", fontsize=8.5)
ax.set_title("Revenue by segment", loc="left", fontsize=11, fontweight="bold", color=NAVY); ax.set_yticklabels([])
ax.set_xlim(0, (seg.revenue.max() / 1e6) * 1.4)

# ---- monthly revenue stacked (drop partial last month)
piv = mrs[mrs.order_month < "2011-12"].pivot(index="order_month", columns="segment", values="revenue").fillna(0)[list(seg.segment)]
ax = fig.add_axes([0.71, 0.47, 0.26, 0.28]); ax.set_facecolor("white")
ax.stackplot(range(len(piv)), (piv.T / 1e3).values, colors=[COL[s] for s in piv.columns], labels=piv.columns, linewidth=0)
ax.set_xticks(range(0, len(piv), 6)); ax.set_xticklabels(piv.index[::6], fontsize=8)
ax.set_title("Monthly revenue by segment (£k)", loc="left", fontsize=11, fontweight="bold", color=NAVY)

# ---- cohort heatmap (first 12 months, 2010 cohorts)
c = coh[(coh.cohort_month >= "2010-01") & (coh.cohort_month <= "2010-12") & (coh.months_since <= 12)]
h = c.pivot(index="cohort_month", columns="months_since", values="retention_pct")
ax = fig.add_axes([0.05, 0.07, 0.40, 0.31])
im = ax.imshow(h.values, cmap="YlGn", vmin=0, vmax=60, aspect="auto")
ax.set_xticks(range(h.shape[1])); ax.set_xticklabels(h.columns, fontsize=8)
ax.set_yticks(range(h.shape[0])); ax.set_yticklabels(h.index, fontsize=8)
for i in range(h.shape[0]):
    for j in range(h.shape[1]):
        v = h.values[i, j]
        if not np.isnan(v): ax.text(j, i, f"{v:.0f}", ha="center", va="center", fontsize=7, color="black" if v < 45 else "white")
ax.set_title("Cohort retention % (month 0 = 100%, shown 1–12 only for 2010 cohorts)", loc="left", fontsize=10.5, fontweight="bold", color=NAVY)
ax.set_xlabel("Months since first purchase", fontsize=8.5); ax.spines[:].set_visible(False)

# ---- repeat rate by first-order quarter
ax = fig.add_axes([0.53, 0.07, 0.22, 0.31]); ax.set_facecolor("white")
ax.bar(rep.first_order_quarter, rep.repeat_rate_pct, color="#2D7DD2")
for x, v in zip(range(len(rep)), rep.repeat_rate_pct): ax.text(x, v + 1.5, f"{v:.0f}%", ha="center", fontsize=8)
ax.set_xticks(range(len(rep))); ax.set_xticklabels(rep.first_order_quarter, rotation=45, fontsize=8, ha="right")
ax.set_title("Repeat purchase rate by first-order quarter", loc="left", fontsize=10.5, fontweight="bold", color=NAVY); ax.set_ylim(0, 100)

# ---- action table
ax = fig.add_axes([0.78, 0.07, 0.20, 0.31]); ax.axis("off")
ax.set_title("Where to act first", loc="left", fontsize=10.5, fontweight="bold", color=NAVY)
rows = [("Can't Lose Them", "£1.57M lapsed", COL["Cant Lose Them"]), ("At Risk", "£0.21M lapsed", COL["At Risk"]),
        ("New Customers", "357 need order #2", COL["New Customers"]), ("Champions", "47% of revenue", COL["Champions"])]
for i, (a, b, col) in enumerate(rows):
    y = 0.80 - i * 0.22
    ax.add_patch(plt.Rectangle((0, y - 0.08), 0.03, 0.16, color=col, transform=ax.transAxes))
    ax.text(0.07, y + 0.02, a, fontsize=10, fontweight="bold", color=NAVY, transform=ax.transAxes)
    ax.text(0.07, y - 0.07, b, fontsize=9, color="#5C677D", transform=ax.transAxes)

fig.text(0.03, 0.012, "*Revenue at risk = lifetime revenue of customers in At Risk + Cant Lose Them. Preview image rendered in Python from the pipeline output; "
         "the Power BI build guide recreates this layout.", fontsize=8, color="#5C677D")
out = ROOT / "powerbi" / "dashboard_preview.png"
fig.savefig(out, dpi=130, facecolor=fig.get_facecolor()); print("saved", out)
