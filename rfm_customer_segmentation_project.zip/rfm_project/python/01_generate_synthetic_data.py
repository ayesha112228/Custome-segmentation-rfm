"""
Generate a synthetic dataset with the SAME schema as the Kaggle / UCI "Online Retail II" dataset.

Columns: Invoice, StockCode, Description, Quantity, InvoiceDate, Price, Customer ID, Country

Why synthetic? It lets the whole pipeline run end-to-end offline and reproducibly.
To use the real data instead, download Online Retail II from Kaggle, save it as
data/raw/online_retail_II.csv (same column names) and re-run 02_run_pipeline.py.

The generator deliberately injects the mess you find in real retail data:
  - guest checkouts (missing Customer ID)
  - cancellations / returns (Invoice starting with 'C', negative Quantity)
  - zero / negative prices (adjustments)
  - non-product stock codes (POST, D, M, BANK CHARGES, ...)
  - exact duplicate lines
"""
import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)

START = pd.Timestamp("2009-12-01")
END = pd.Timestamp("2011-12-09")
TOTAL_DAYS = (END - START).days

# ---------------------------------------------------------------- product catalogue
adjectives = ["VINTAGE", "RETRO", "RED", "BLUE", "GREEN", "PINK", "IVORY", "WOODEN", "CERAMIC",
              "GLASS", "METAL", "FELT", "PAPER", "HAND PAINTED", "SCANDI", "FLORAL", "STRIPED", "SPOTTY"]
nouns = ["MUG", "CANDLE HOLDER", "BUNTING", "TEA TOWEL", "CUSHION COVER", "LUNCH BAG", "STORAGE TIN",
         "PHOTO FRAME", "NOTEBOOK", "GIFT WRAP", "DOORSTOP", "HOT WATER BOTTLE", "BIRDHOUSE",
         "WALL CLOCK", "JAR SET", "T-LIGHT HOLDER", "PLACEMAT", "KEY RING", "APRON", "COASTER SET"]

catalogue = []
for i in range(320):
    desc = f"{rng.choice(adjectives)} {rng.choice(nouns)}"
    price = float(np.round(rng.lognormal(mean=1.0, sigma=0.7), 2))
    price = min(max(price, 0.29), 45.0)
    catalogue.append((f"{10000 + i}", desc, price))
cat_codes = np.array([c[0] for c in catalogue])
cat_desc = np.array([c[1] for c in catalogue])
cat_price = np.array([c[2] for c in catalogue])
# popularity weights (some products sell far more than others)
pop = rng.pareto(1.6, size=len(catalogue)) + 1
pop = pop / pop.sum()

# ---------------------------------------------------------------- customer archetypes
# share, start_range(days), active_until_range(days from START), orders per active month, basket scale, max_orders
ARCHETYPES = {
    #  name               share  start       last_active      rate  scale  cap
    "champion":          (0.09, (0, 330),    (680, 738),      1.30, 1.8,  None),
    "loyal":             (0.16, (0, 450),    (560, 738),      0.75, 1.2,  None),
    "cant_lose":         (0.05, (0, 200),    (300, 520),      1.00, 3.2,  None),
    "at_risk":           (0.14, (0, 300),    (350, 560),      0.85, 1.3,  None),
    "new_repeat":        (0.09, (610, 700),  (715, 738),      1.10, 1.0,  None),
    "new_one_time":      (0.12, (680, 735),  (680, 738),      0.00, 0.9,  1),
    "promising":         (0.07, (450, 640),  (600, 738),      0.30, 0.9,  2),
    "hibernating":       (0.30, (0, 560),    (0, 560),        0.25, 0.7,  3),
}

N_CUSTOMERS = 2600
customers = []
cid = 12346
names = list(ARCHETYPES)
shares = np.array([ARCHETYPES[n][0] for n in names])
shares = shares / shares.sum()
assignments = rng.choice(len(names), size=N_CUSTOMERS, p=shares)

countries = ["United Kingdom", "Germany", "France", "EIRE", "Spain", "Netherlands",
             "Belgium", "Switzerland", "Portugal", "Australia"]
country_p = np.array([0.88, 0.03, 0.025, 0.015, 0.01, 0.01, 0.007, 0.007, 0.006, 0.005])
country_p = country_p / country_p.sum()

rows = []
invoice_no = 489434


def add_order(customer_id, country, date, scale, is_guest=False):
    """Create one invoice worth of line items."""
    global invoice_no
    invoice_no += 1
    n_lines = int(np.clip(rng.lognormal(mean=2.0, sigma=0.7) * (0.7 + 0.3 * scale), 1, 60))
    prods = rng.choice(len(catalogue), size=n_lines, replace=False, p=pop)
    # time of day between 08:00 and 17:00
    ts = date + pd.Timedelta(hours=int(rng.integers(8, 18)), minutes=int(rng.integers(0, 60)))
    lines = []
    for p in prods:
        qty = int(np.clip(rng.lognormal(mean=1.6, sigma=0.8) * (0.6 + 0.4 * scale), 1, 400))
        lines.append([str(invoice_no), cat_codes[p], cat_desc[p], qty, ts, cat_price[p],
                      np.nan if is_guest else customer_id, country])
    rows.extend(lines)
    return str(invoice_no), lines


order_log = []  # (customer, invoice, lines) to build some returns later

for i in range(N_CUSTOMERS):
    arche = names[assignments[i]]
    share, start_r, last_r, rate, scale, cap = ARCHETYPES[arche]
    customer_id = cid + i * 2 + int(rng.integers(0, 2))
    country = rng.choice(countries, p=country_p)
    start = int(rng.integers(start_r[0], start_r[1] + 1))
    last = int(rng.integers(last_r[0], last_r[1] + 1))
    if arche == "hibernating":
        # drifts away within ~6 months of joining, never later than day 560
        last = min(start + int(rng.integers(0, 200)), 560)
    last = max(last, start)
    cust_scale = float(rng.lognormal(mean=np.log(scale), sigma=0.35))

    if arche == "new_one_time":
        n_orders = 1
        dates = [start]
    else:
        months_active = max((last - start) / 30.0, 0.0)
        expected = rate * months_active
        n_orders = 1 + int(rng.poisson(expected))
        if cap:
            n_orders = min(n_orders, int(rng.integers(1, cap + 1)))
        dates = sorted(set(int(d) for d in rng.integers(start, last + 1, size=n_orders - 1))) if n_orders > 1 else []
        dates = [start] + dates

    for d in dates:
        date = START + pd.Timedelta(days=min(d, TOTAL_DAYS))
        # seasonality: pull some orders into Q4 (gifting season)
        if date.month in (9, 10, 11) and rng.random() < 0.15:
            pass
        inv, lines = add_order(customer_id, country, date, cust_scale)
        order_log.append((customer_id, inv, lines, country))

# ---------------------------------------------------------------- guest checkouts (no Customer ID)
for _ in range(1500):
    d = int(rng.integers(0, TOTAL_DAYS + 1))
    add_order(np.nan, "United Kingdom", START + pd.Timedelta(days=d), 0.8, is_guest=True)

df = pd.DataFrame(rows, columns=["Invoice", "StockCode", "Description", "Quantity",
                                 "InvoiceDate", "Price", "Customer ID", "Country"])

# ---------------------------------------------------------------- returns / cancellations (~3% of orders)
ret_rows = []
sample = rng.choice(len(order_log), size=int(len(order_log) * 0.03), replace=False)
for idx in sample:
    customer_id, inv, lines, country = order_log[idx]
    invoice_no += 1
    k = max(1, int(len(lines) * rng.uniform(0.2, 1.0)))
    for ln in lines[:k]:
        ts = ln[4] + pd.Timedelta(days=int(rng.integers(1, 20)))
        if ts > END:
            continue
        ret_rows.append([f"C{invoice_no}", ln[1], ln[2], -ln[3], ts, ln[5], customer_id, country])
df = pd.concat([df, pd.DataFrame(ret_rows, columns=df.columns)], ignore_index=True)

# ---------------------------------------------------------------- non-product + junk rows
extra = []
junk = [("POST", "POSTAGE", 18.0), ("D", "Discount", 7.5),
        ("M", "Manual", 12.0), ("BANK CHARGES", "Bank Charges", 15.0)]
for _ in range(400):
    r = df.iloc[int(rng.integers(0, len(df)))]
    code, desc, price = junk[int(rng.integers(0, len(junk)))]
    extra.append([r["Invoice"], code, desc, 1, r["InvoiceDate"], price, r["Customer ID"], r["Country"]])
df = pd.concat([df, pd.DataFrame(extra, columns=df.columns)], ignore_index=True)

# zero-price adjustments
zero_idx = rng.choice(len(df), size=250, replace=False)
df.loc[zero_idx, "Price"] = 0.0

# exact duplicate lines (~0.5%)
dups = df.sample(frac=0.005, random_state=7)
df = pd.concat([df, dups], ignore_index=True)

df = df.sort_values(["InvoiceDate", "Invoice"]).reset_index(drop=True)
df["InvoiceDate"] = df["InvoiceDate"].dt.strftime("%Y-%m-%d %H:%M:%S")
df["Customer ID"] = df["Customer ID"].astype("Int64")

out = Path(__file__).resolve().parents[1] / "data" / "raw" / "online_retail_II.csv"
df.to_csv(out, index=False)
print(f"Wrote {len(df):,} rows -> {out}")
print(f"Invoices: {df['Invoice'].nunique():,}  Customers: {df['Customer ID'].nunique():,}")
