"""
Load raw CSV -> SQLite -> run the SQL scripts in /sql -> export CSVs for Power BI.

Usage:  python 02_run_pipeline.py
Input : data/raw/online_retail_II.csv  (synthetic by default; drop in the real Kaggle file to use it)
Output: data/processed/*.csv  and  data/retail.db
"""
import sqlite3
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw" / "online_retail_II.csv"
OUT = ROOT / "data" / "processed"
DB = ROOT / "data" / "retail.db"
OUT.mkdir(exist_ok=True)

# ---- 1. load raw (tolerate the column-name variants found across Kaggle versions)
df = pd.read_csv(RAW, dtype={"Invoice": str, "InvoiceNo": str, "StockCode": str})
rename = {"InvoiceNo": "invoice", "Invoice": "invoice", "StockCode": "stock_code",
          "Description": "description", "Quantity": "quantity", "InvoiceDate": "invoice_date",
          "UnitPrice": "price", "Price": "price", "CustomerID": "customer_id",
          "Customer ID": "customer_id", "Country": "country"}
df = df.rename(columns=rename)
df["invoice_date"] = pd.to_datetime(df["invoice_date"]).dt.strftime("%Y-%m-%d %H:%M:%S")
df["customer_id"] = df["customer_id"].astype("Int64")
df["invoice"] = df["invoice"].astype(str)
df["stock_code"] = df["stock_code"].astype(str).str.strip()

if DB.exists():
    DB.unlink()
con = sqlite3.connect(DB)
df[["invoice", "stock_code", "description", "quantity", "invoice_date",
    "price", "customer_id", "country"]].to_sql("raw_retail", con, index=False)
print(f"Loaded {len(df):,} raw rows")

# ---- 2. run SQL scripts in order
for sql_file in sorted((ROOT / "sql").glob("0*.sql")):
    con.executescript(sql_file.read_text())
    print("Ran", sql_file.name)

# ---- 3. export
q = lambda sql: pd.read_sql_query(sql, con)

dim_customer = q("""
    SELECT c.customer_id, c.country, c.first_order_date, c.last_order_date,
           c.recency_days, c.frequency, c.monetary, c.avg_order_value,
           c.r_score, c.f_score, c.m_score, c.rfm_code, c.rfm_total, c.segment,
           COALESCE(r.return_invoices, 0) AS return_invoices,
           COALESCE(r.return_value, 0)    AS return_value
    FROM customer_segments c LEFT JOIN customer_returns r USING (customer_id)
""")
dim_customer.to_csv(OUT / "dim_customer.csv", index=False)

for table in ["fact_orders", "dim_segment", "segment_summary", "cohort_retention",
              "monthly_revenue_segment", "repeat_purchase", "revenue_concentration", "dq_log"]:
    q(f"SELECT * FROM {table}").to_csv(OUT / f"{table}.csv", index=False)

# date dimension for time intelligence in Power BI
dates = pd.date_range(df["invoice_date"].min()[:10], df["invoice_date"].max()[:10], freq="D")
pd.DataFrame({
    "date": dates.strftime("%Y-%m-%d"),
    "year": dates.year, "quarter": "Q" + dates.quarter.astype(str),
    "month_num": dates.month, "month_name": dates.strftime("%b"),
    "year_month": dates.strftime("%Y-%m"), "weekday": dates.strftime("%a"),
}).to_csv(OUT / "dim_date.csv", index=False)

# ---- 4. quick sanity print
print("\n--- Data quality log ---");   print(q("SELECT * FROM dq_log").to_string(index=False))
print("\n--- Segment summary ---");    print(q("SELECT * FROM segment_summary").to_string(index=False))
print("\n--- Repeat purchase ---");    print(q("SELECT * FROM repeat_purchase").to_string(index=False))
print("\n--- Revenue concentration ---"); print(q("SELECT * FROM revenue_concentration").to_string(index=False))
print("\nSnapshot date:", q("SELECT snapshot_date FROM params").iloc[0, 0])
con.close()
